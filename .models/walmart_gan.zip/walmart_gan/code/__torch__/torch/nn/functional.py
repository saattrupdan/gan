op_version_set = 1
def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _0 = torch.__isnot__(bias, None)
  else:
    _0 = False
  if _0:
    bias0 = unchecked_cast(Tensor, bias)
    ret = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output0 = torch.add_(output, bias1, alpha=1)
    else:
      output0 = output
    ret = output0
  return ret
