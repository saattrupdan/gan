op_version_set = 1
def apply_permutation(tensor: Tensor,
    permutation: Tensor,
    dim: int=1) -> Tensor:
  _0 = torch.index_select(tensor, dim, permutation)
  return _0
