op_version_set = 1
class RGAN(Module):
  __parameters__ = []
  training : bool
  gen : __torch__.models.RGenerator
  crt : __torch__.models.RCritic
  def forward(self: __torch__.models.RGAN,
    x: Tensor) -> Tensor:
    fake = (self.gen).forward(x, )
    return (self.crt).forward(fake, )
class RGenerator(Module):
  __parameters__ = []
  training : bool
  rnn : __torch__.torch.nn.modules.rnn.GRU
  proj : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.models.RGenerator,
    x: Tensor) -> Tensor:
    x0, _0, = (self.rnn).forward__0(x, None, )
    return (self.proj).forward(x0, )
class RCritic(Module):
  __parameters__ = []
  training : bool
  rnn : __torch__.torch.nn.modules.rnn.___torch_mangle_0.GRU
  proj : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  def forward(self: __torch__.models.RCritic,
    x: Tensor) -> Tensor:
    _1, x1, = (self.rnn).forward__0(x, None, )
    return (self.proj).forward(x1, )
