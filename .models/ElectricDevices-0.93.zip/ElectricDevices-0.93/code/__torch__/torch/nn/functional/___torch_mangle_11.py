op_version_set = 1
def batch_norm(input: Tensor,
    running_mean: Optional[Tensor],
    running_var: Optional[Tensor],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    training: bool=False,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  if training:
    size = torch.size(input)
    size_prods = size[0]
    size_prods0 = size_prods
    for i in range(torch.sub(torch.len(size), 2)):
      size_prods0 = torch.mul(size_prods0, size[torch.add(i, 2)])
    if torch.eq(size_prods0, 1):
      ops.prim.RaiseException("Exception")
    else:
      pass
  else:
    pass
  _0 = torch.batch_norm(input, weight, bias, running_mean, running_var, training, momentum, eps, True)
  return _0
