op_version_set = 1
class Conv1d(Module):
  __parameters__ = ["weight", "bias", ]
  transposed : bool
  weight : Tensor
  training : bool
  bias : Tensor
  def forward(self: __torch__.torch.nn.modules.conv.Conv1d,
    input: Tensor) -> Tensor:
    _0 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _3 = torch.floordiv(torch.add(4, 1), 2)
      _4 = __torch__.torch.nn.functional.pad(input, [_3, torch.floordiv(4, 2)], "circular", 0., )
      _5 = self.weight
      _6 = self.bias
      _7 = [0]
      _1, _2 = True, torch.conv1d(_4, _5, _6, [1], _7, [1], 1)
    else:
      _1, _2 = False, _0
    if _1:
      _8 = _2
    else:
      _8 = torch.conv1d(input, self.weight, self.bias, [1], [4], [1], 1)
    return _8
