op_version_set = 1
class BatchNorm1d(Module):
  __parameters__ = ["weight", "bias", ]
  running_var : Tensor
  running_mean : Tensor
  num_batches_tracked : Tensor
  weight : Tensor
  training : bool
  bias : Tensor
  def forward(self: __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm1d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.___torch_mangle_11.batch_norm
    _1 = (self)._check_input_dim(input, )
    if self.training:
      _2 = True
    else:
      _2 = False
    if _2:
      _3 = torch.add(self.num_batches_tracked, 1, 1)
      self.num_batches_tracked = _3
      exponential_average_factor = 0.10000000000000001
    else:
      exponential_average_factor = 0.10000000000000001
    _4 = self.running_mean
    _5 = self.running_var
    _6 = self.weight
    _7 = self.bias
    if self.training:
      _8 = True
    else:
      _8 = torch.__not__(True)
    _9 = _0(input, _4, _5, _6, _7, _8, exponential_average_factor, 1.0000000000000001e-05, )
    return _9
  def _check_input_dim(self: __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm1d,
    input: Tensor) -> None:
    if torch.ne(torch.dim(input), 2):
      _10 = torch.ne(torch.dim(input), 3)
    else:
      _10 = False
    if _10:
      ops.prim.RaiseException("Exception")
    else:
      pass
    return None
