op_version_set = 1
class Conv1d(Module):
  __parameters__ = ["weight", "bias", ]
  transposed : bool
  weight : Tensor
  training : bool
  bias : Tensor
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv1d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.___torch_mangle_12.pad
    _1 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _4 = torch.floordiv(torch.add(1, 1), 2)
      _5 = _0(input, [_4, torch.floordiv(1, 2)], "circular", 0., )
      _6 = self.weight
      _7 = self.bias
      _8 = [0]
      _2, _3 = True, torch.conv1d(_5, _6, _7, [1], _8, [1], 1)
    else:
      _2, _3 = False, _1
    if _2:
      _9 = _3
    else:
      _9 = torch.conv1d(input, self.weight, self.bias, [1], [1], [1], 1)
    return _9
