op_version_set = 1
class TSCResNet(Module):
  __parameters__ = []
  training : bool
  block1 : __torch__.tsc_model.ResBlock
  block2 : __torch__.tsc_model.___torch_mangle_4.ResBlock
  block3 : __torch__.tsc_model.___torch_mangle_4.ResBlock
  proj : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.tsc_model.TSCResNet,
    x: Tensor) -> Tensor:
    x0 = (self.block1).forward(x, )
    x1 = (self.block2).forward(x0, )
    x2 = (self.block3).forward(x1, )
    x3 = torch.mean(x2, [2], False, dtype=None)
    x4 = (self.proj).forward(x3, )
    return torch.softmax(x4, 1, None)
class ResBlock(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.conv.Conv1d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm1d
  conv3 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv1d
  bn3 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm1d
  def forward(self: __torch__.tsc_model.ResBlock,
    input: Tensor) -> Tensor:
    x = (self.conv1).forward(input, )
    x5 = (self.bn1).forward(x, )
    x6 = __torch__.utils.mish(x5, )
    x7 = (self.conv2).forward(x6, )
    x8 = (self.bn2).forward(x7, )
    x9 = __torch__.utils.mish(x8, )
    x10 = (self.conv3).forward(x9, )
    x11 = (self.bn3).forward(x10, )
    x12 = __torch__.utils.mish(x11, )
    return torch.add(x12, input, alpha=1)
