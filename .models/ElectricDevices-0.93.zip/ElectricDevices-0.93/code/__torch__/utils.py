op_version_set = 1
class TimeSeriesStationariser(Module):
  __parameters__ = []
  stds : Tensor
  training : bool
  means : Tensor
  def forward(self: __torch__.utils.TimeSeriesStationariser,
    x: Tensor) -> Tensor:
    _0 = torch.div(torch.sub(x, self.means, alpha=1), self.stds)
    return _0
def mish(x: Tensor) -> Tensor:
  _1 = torch.mul(x, torch.tanh(torch.softplus(x, 1, 20)))
  return _1
