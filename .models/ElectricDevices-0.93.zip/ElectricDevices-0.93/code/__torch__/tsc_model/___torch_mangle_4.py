op_version_set = 1
class ResBlock(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv1d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm1d
  conv3 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv1d
  bn3 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm1d
  def forward(self: __torch__.tsc_model.___torch_mangle_4.ResBlock,
    input: Tensor) -> Tensor:
    x = (self.conv1).forward(input, )
    x0 = (self.bn1).forward(x, )
    x1 = __torch__.utils.mish(x0, )
    x2 = (self.conv2).forward(x1, )
    x3 = (self.bn2).forward(x2, )
    x4 = __torch__.utils.mish(x3, )
    x5 = (self.conv3).forward(x4, )
    x6 = (self.bn3).forward(x5, )
    x7 = __torch__.utils.mish(x6, )
    return torch.add(x7, input, alpha=1)
